// Joyride demo
$('#start-jr').on('click', function() {
  $(document).foundation('joyride','start');
});